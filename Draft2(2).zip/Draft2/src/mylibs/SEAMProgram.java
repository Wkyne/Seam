/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mylibs;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class SEAMProgram {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    static SEAMProgram instance = null;
    private ArrayList<Equipment> equipList;
    private ArrayList<Room> roomList;
    private ArrayList<User> userList;



    public ArrayList<Equipment> getEquipList() {
        return equipList;
    }

    public ArrayList<Room> getRoomList() {
        return roomList;
    }

    public ArrayList<User> getUserList() {
        return userList;
    }
    
    private SEAMProgram() {
        userList = new ArrayList<>();
        equipList = new ArrayList<>();
        roomList = new ArrayList<>();
    }

    public static SEAMProgram getInstance() {
        if (instance == null) {
            instance = new SEAMProgram();
        }
        return instance;
    }
    
    //filestreamstuff
    
     public void writeToText() throws FileNotFoundException {
        try (PrintWriter equipmentWriter = new PrintWriter("equipment.txt");
             PrintWriter roomWriter = new PrintWriter("rooms.txt");
             PrintWriter userWriter = new PrintWriter("users.txt")) {
             
            for (Equipment equipment : equipList) {
                String equipmentData = equipment.getId() + "|" + equipment.getName() + "|" +
                        equipment.getCondition() + "|" + equipment.getRoom();
                equipmentWriter.println(equipmentData);
            }
            
            for (Room room : roomList) {
                String roomData = room.getId() + "|" + room.getName();
                roomWriter.println(roomData);
            }
            
            for (User user : userList) {
            String dateStr = dateFormat.format(user.getDateJoined()); // Format date to string
            String userData = user.getId() + "|" + user.getName() + "|" + user.getPass() + "|" + user.getRole() + "|" 
                            // + user.getEmail() + "|" + dateStr + "|" + user.getCellNum();                            
                            + user.getEmail() + "|" + dateStr + "|" + user.getAgeText();

            userWriter.println(userData);
            }
        }
    }

    // Combined read method
    public void readFromText() throws IOException, ParseException {
        
        equipList = new ArrayList<>();
        roomList = new ArrayList<>();
        userList = new ArrayList<>();
        
        try (BufferedReader equipmentReader = new BufferedReader(new FileReader("equipment.txt"));
             BufferedReader roomReader = new BufferedReader(new FileReader("rooms.txt"));
             BufferedReader userReader = new BufferedReader(new FileReader("users.txt"))) {
             
            String line;
            while ((line = roomReader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 2) {
                    Room room = new Room(parts[0], parts[1]);
                    roomList.add(room);
                }
            }
            while ((line = equipmentReader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 4) {
                    Equipment e = new Equipment(parts[1], parts[2]);
                    for (Room r: roomList)
                        if (r.getName().equalsIgnoreCase(parts[3]))
                            r.assignEquipment(e);
                    equipList.add(e);
                }
            }
            
            
            UserManager manager;
            while ((line = userReader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 7) {
                    User user;
                    
                    if (parts[3].equals("manager")) {
                        manager = new UserManager(new AdminUserBuilder());
                        // user = manager.constructUser(parts[1], parts[2], parts[4], dateFormat.parse(parts[5]), Integer.parseInt(parts[6]));
                        user = manager.constructUser(parts[1], parts[2], parts[4], Integer.parseInt(parts[6]), dateFormat.parse(parts[5]));
                    } else {//id name pass role email date number
                        manager = new UserManager(new DefaultUserBuilder());
                        //user = manager.constructUser(parts[1], parts[2], parts[4], dateFormat.parse(parts[5]), Integer.parseInt(parts[6]));
                        user = manager.constructUser(parts[1], parts[2], parts[4], Integer.parseInt(parts[6]), dateFormat.parse(parts[5]));
                    }
                    userList.add(user);
                }
            }
        }
    }

    public void saveToFile() {
        try {
            writeToText();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void loadFromFile() throws ParseException {
        try {
            readFromText();
        } catch (IOException e) {
            System.out.println("File not found. Starting with a new instance.");
        }
    }
    
    
    
    
    
    


    
    
    
    
    
    
    
    
    
    public String displayEquipCondition(boolean Ascending){
        String list ="";
        list += "-------------------------------\n";
        list += "ID\tName\t\tCondition\n";
        list += "-------------------------------\n";
        for (Equipment e: this.equipList){
            if (Ascending)
                list +=e.getId()+"\t"+ e.getName()+"\t\t"+ e.getCondition()+"\n";
            
        }
        list += "-------------------------------\n";
        return list;
    }
    
    public String displayRestockList(){
        String list = "Items due for restocking\n"; 
        list += "-------------------------------\n";
        list += "Item\tQuantity\n";
        list += "-------------------------------\n";
        String[] types = {"projector","TV","Chair","monitor","CPU"};
        int[]count = new int[5]; //projector,TV,chair,monitor,CPU respectively
        for (Equipment e: this.equipList){
            if (e.getCondition().equalsIgnoreCase("lost") || e.getCondition().equalsIgnoreCase("broken")) {
                if (e.getName().equalsIgnoreCase(types[0]))
                    count[0]++;
                if (e.getName().equalsIgnoreCase(types[1]))
                    count[1]++;
                if (e.getName().equalsIgnoreCase(types[2]))
                    count[2]++;
                if (e.getName().equalsIgnoreCase(types[3]))
                    count[3]++;
                if (e.getName().equalsIgnoreCase(types[4]))
                    count[4]++;
            }
        }
        for (int i = 0; i<5;i++){
            list += types[i] +"\t"+ Math.max(0,count[i])+"\n";   
        }
        list += "-------------------------------\n";
        return list;
    }
    
    public String searchList(String id){
        String list = "";
        if (findEquipment(id)==null){
            return "No items with that Id";
        }
        Equipment e = findEquipment(id);
        list +=  e.getName()+" "+e.getId()+" "+e.getCondition()+" "+e.getRoom();
        return list;
    }
    
    public void filteredList(String filter,boolean isAvail){
        String list = "";
        list += "-------------------------------\n";
        list += "ID\tName\t\tCondition\n";
        list += "-------------------------------\n";
        for (Equipment e: equipList)
            if (e.getName().equalsIgnoreCase(filter))
                list += e.getName()+" "+e.getId()+" "+e.getCondition()+" ";
                if (false || isAvail)
              //    list += e.getCondition()
        list += "-------------------------------\n";
        System.out.println(list);
    }
            
    public Room findRoom(String id) {
        for (Room room : roomList) {
            if (room.getId().equalsIgnoreCase(id)) {
                return room;
            }
        }
        return null;
    }          
    public Equipment findEquipment(String id){
        for (Equipment e: equipList){
            if (e.getId().equalsIgnoreCase(id)){
                return e;
            }
        }   
        return null;
    }       
            
    
    public void editEquipment(String id,String room, String condition){
        if (findEquipment(id)==null){
            System.out.println("Not found");
            return;
        }
        findEquipment(id).setCondition(condition);  
        for (Room r:roomList)
            if (r.getName().equalsIgnoreCase(room))
                r.unassignEquipment(findEquipment(id));
        findEquipment(id).setRoom(room);
                        
    }
    public void addEquipment(String name, String condition) {
        Equipment equipment = new Equipment(name, condition);
        equipList.add(equipment);
    }
    
    public void removeEquipment(String id){
        if (findEquipment(id)==null){
            System.out.println("Not found");
            return;
        }
        equipList.remove(findEquipment(id));
    }
    
    public void addRoom(String id, String name) {
        int count = 1;
        Room room = new Room(id, name);
        for(Room r: roomList){
            count++;
        }
        if (count>=3){
            System.out.println("Maximum Room Capacity");
        }
        else
            roomList.add(room);
    }
            
    public void editRoom(String id, String name) {
        if (findRoom(id) != null) {
            findRoom(id).setName(name);
        }
    }
    
    public void removeRoom(String id) {
        if (findRoom(id) == null) {
            System.out.println("Not found");
            return;
        }
        roomList.remove(findRoom(id));
    }
            
            
     

    public void returnEquipment(String id,String condition){
        if (findEquipment(id)==null){
            System.out.println("Not found");
            return;
        }
        for (Room r:roomList)
            if (r.getName().equalsIgnoreCase(findEquipment(id).getRoom()))
                r.unassignEquipment(findEquipment(id));
        findEquipment(id).setCondition(condition);
    }
    
    
    
    
    public void sortedconditionlist(){
//        for (Equipment e: equipList)
//            if (e.)
    }
    

    
   public void displayAllUsers() {
        System.out.println("All Users:");
        System.out.println("------------------------------------------------");
        for (User user : userList) {
            System.out.println("ID: " + user.getId());
            System.out.println("Name: " + user.getName());
            System.out.println("Email: " + user.getEmail());
            System.out.println("Role: " + user.getRole());
            System.out.println("Date Joined: " + dateFormat.format(user.getDateJoined()));
            // System.out.println("Cell Number: " + user.getCellNum());
            System.out.println("Age: " + user.getAgeText());
            System.out.println("------------------------------------------------");
        }
    }       

    public void displayAllEquipment() {
        System.out.println("All Equipment:");
        System.out.println("------------------------------------------------");
        for (Equipment equipment : equipList) {
            System.out.println("ID: " + equipment.getId());
            System.out.println("Name: " + equipment.getName());
            System.out.println("Condition: " + equipment.getCondition());
            System.out.println("Room: " + equipment.getRoom());
            System.out.println("------------------------------------------------");
        }
    }

    public void displayAllRooms() {
        System.out.println("All Rooms:");
        System.out.println("------------------------------------------------");
        for (Room room : roomList) {
            System.out.println("ID: " + room.getId());
            System.out.println("Name: " + room.getName());
            System.out.println("------------------------------------------------");
        }
    }

    
    
}
