/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author djbgr
 */
public class Admin extends User{
    private boolean hasAccess;
    private String rank;

    public boolean isHasAccess() {
        return hasAccess;
    }

    @Override
    public void setHasAccess() {
        this.hasAccess = true;
    }

    public String getRank() {
        return rank;
    }

    @Override
    public void setRank() {
        this.rank = "supervisor";
    }
    
    
    
}
