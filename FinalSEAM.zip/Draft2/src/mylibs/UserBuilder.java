/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

import java.util.Date;

/**
 *
 * @author Administrator
 */
public interface UserBuilder {
    public void setName(String name); // Part[1]
    public void setPass(String pass); // Part[2]
    public void setRole(); // Part[3]
    public void setId(); // Part[4]
    public void setEmail(String email); // Part[5]
    public void setDateJoined(Date dateJoined); // Part[6]
    public void setAgeText(int AgeText); // Part[7]
    public User getUser();
}
