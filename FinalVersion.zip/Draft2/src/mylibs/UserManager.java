/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

import java.util.Date;

/**
 *
 * @author Administrator
 */


public class UserManager {
    private final UserBuilder builder;

    public UserManager(UserBuilder builder) {
        this.builder = builder;
    }

    // public User constructUser(String name, String pass, String email, Date dateJoined, int cellNum) {
    public User constructUser(String name, String pass, String email, int AgeText, Date dateJoined) {
        builder.setName(name);
        builder.setPass(pass);
        builder.setRole();
        builder.setId(); // Assuming ID is set automatically
        builder.setEmail(email);
        builder.setDateJoined(dateJoined);
//        builder.setCellNum(cellNum);
        builder.setAgeText(AgeText);
        return builder.getUser();
    }
}

