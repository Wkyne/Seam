/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author Administrator
 */
public class Equipment {
    
    private String id;
    private String name;
    private String condition;
    private String room; // Where it is currently assigned

    public Equipment(String id, String name, String condition) {
        this.id = id;
        this.condition = condition;
        this.room = "none";
        //defined types of equipment
        if ("projector".equalsIgnoreCase(name)||"TV".equalsIgnoreCase(name)||"Chair".equalsIgnoreCase(name)||"Monitor".equalsIgnoreCase(name)||"CPU".equalsIgnoreCase(name))
            this.name = name;
    }

    // Getters and setters
    public String getId(){ 
        return id; 
    }
    public String getName(){ 
        return name; 
    }
    public String getCondition(){ 
        return condition; 
    }
    public String getRoom(){
        return room; 
    } 

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public void setRoom(String room) { 
        this.room = room;
    }
}
