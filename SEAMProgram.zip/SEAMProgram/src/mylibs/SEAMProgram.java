/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mylibs;

import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class SEAMProgram {
    static SEAMProgram instance = null;
    private ArrayList<Equipment> equipList;
    private ArrayList<Room> roomList;
    private ArrayList<User> userList;

    public static final int MAX_PROJECTORS = 10;
    public static final int MAX_TV = 5;
    public static final int MAX_CHAIRS = 50;
    public static final int MAX_MONITORS = 20;
    public static final int MAX_CPUS = 15;
    
    private SEAMProgram() {
        userList = new ArrayList<>();
        equipList = new ArrayList<>();
        roomList = new ArrayList<>();
    }

    public static SEAMProgram getInstance() {
        if (instance == null) {
            instance = new SEAMProgram();
        }
        return instance;
    }
    
    
    
}
