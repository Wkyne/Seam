/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author Administrator
 */
public interface UserBuilder {
    void setName(String name);
    void setPass(String pass);
    void setIsManager();
    void setId();
    User getUser();
}
