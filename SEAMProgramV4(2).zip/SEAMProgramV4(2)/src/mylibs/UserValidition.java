/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package mylibs;

/**
 *
 * @author Administrator
 */
public interface UserValidition {
    public void checkUser(String name, String pass);
}





