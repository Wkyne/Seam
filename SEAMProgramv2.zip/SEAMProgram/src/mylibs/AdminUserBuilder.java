/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author Administrator
 */
public class AdminUserBuilder implements UserBuilder{
    private User user;
    private int adminCount = 1;
    
    public AdminUserBuilder(){
        user = new User();
    }
    
    @Override
    public void setName(String name) {
        user.setName(name);
    }

    @Override
    public void setPass(String pass) {
        user.setPass(pass);
    }

    @Override
    public User getUser() {
        return user;
    }
    
    public void setIsManager() {
        user.setIsManager(true);
    }
    
    public void setId(){
        user.setId("M"+adminCount);
        this.adminCount++;
    }
    
    
    
    
}
