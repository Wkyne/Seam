/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author Administrator
 */
public class DefaultUserBuilder implements UserBuilder{
    private User user;
    private int userCount = 1;
    
    public DefaultUserBuilder(){
        user = new User();
    }
    @Override
    public void setName(String name) {
        
    }

    @Override
    public void setPass(String pass) {
        
    }

    @Override
    public User getUser() {
        return user;
    }
    
    @Override
    public void setIsManager() {
        user.setIsManager(false);
    }
    public void setId(){
        user.setId("M"+userCount);
        this.userCount++;
    }
}
