/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mylibs;

import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class SEAMProgram {
    static SEAMProgram instance = null;
    private ArrayList<Equipment> equipList;
    private ArrayList<Room> roomList;
    private ArrayList<User> userList;

    private static final int[] min_Count = {10, 5, 50, 20, 15};
//    public static final int MAX_PROJECTORS = 10;
//    public static final int MAX_TV = 5;
//    public static final int MAX_CHAIRS = 50;
//    public static final int MAX_MONITORS = 20;
//    public static final int MAX_CPUS = 15;

    public ArrayList<Equipment> getEquipList() {
        return equipList;
    }

    public ArrayList<Room> getRoomList() {
        return roomList;
    }

    public ArrayList<User> getUserList() {
        return userList;
    }
    
    private SEAMProgram() {
        userList = new ArrayList<>();
        equipList = new ArrayList<>();
        roomList = new ArrayList<>();
    }

    public static SEAMProgram getInstance() {
        if (instance == null) {
            instance = new SEAMProgram();
        }
        return instance;
    }
    
    public String displayEquipCondition(boolean Ascending){
        String list ="";
        for (Equipment e: this.equipList){
            if (Ascending)
                list += e.getName() + e.getId() + e.getCondition()+"\n";
            
        }
        
        return list;
    }
    
    public String displayRestockList(){
        String list = ""; 
        String[] types = {"projector","TV","Chair","monitor","CPU"};
        int[]count = new int[5]; //projector,TV,chair,monitor,CPU respectively
        for (Equipment e: this.equipList){
            if (e.getName().equalsIgnoreCase(types[0]))
                count[0]++;
            if (e.getName().equalsIgnoreCase(types[1]))
                count[1]++;
            if (e.getName().equalsIgnoreCase(types[2]))
                count[2]++;
            if (e.getName().equalsIgnoreCase(types[3]))
                count[3]++;
            if (e.getName().equalsIgnoreCase(types[4]))
                count[4]++;
        }
        for (int i = 0; i<5;i++){
            list += types[i] +" "+ Math.max(0, min_Count[i]-count[i]);
            
        }
        return list;
    }
    
}
