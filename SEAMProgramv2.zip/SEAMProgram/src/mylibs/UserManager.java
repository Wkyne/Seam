/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author Administrator
 */
public class UserManager {
    private final UserBuilder builder;
    public UserManager(UserBuilder builder){
        this.builder = builder;
    }
    public User constructUser(String name,String pass){
        builder.setName(name);
        builder.setPass(pass);
        return builder.getUser();
    }
}
