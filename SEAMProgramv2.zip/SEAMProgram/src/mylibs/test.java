/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author Administrator
 */
public class test {
    public static void main(String[] args) {
        SEAMProgram.getEquipList().add(new Equipment("1", "projector", "good"));
        SEAMProgram.getEquipList().add(new Equipment("2", "TV", "fair"));
        SEAMProgram.getEquipList().add(new Equipment("3", "Chair", "excellent"));
        SEAMProgram.getEquipList().add(new Equipment("4", "monitor", "good"));
        SEAMProgram.getEquipList().add(new Equipment("5", "CPU", "fair"));
        SEAMProgram.getEquipList().add(new Equipment("6", "projector", "good"));
        SEAMProgram.getEquipList().add(new Equipment("7", "TV", "fair"));
        SEAMProgram.getEquipList().add(new Equipment("8", "Chair", "excellent"));
        SEAMProgram.getEquipList().add(new Equipment("9", "monitor", "good"));
        SEAMProgram.getEquipList().add(new Equipment("10", "CPU", "fair"));
    }
}
