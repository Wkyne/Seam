/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author Administrator
 */
import java.util.Date;

public class AdminUserBuilder implements UserBuilder {
    private User user;
    private static int adminCount = 1;
    
    public AdminUserBuilder() {
        user = new User();
    }

    @Override
    public void setName(String name) {
        user.setName(name);
    }

    @Override
    public void setPass(String pass) {
        user.setPass(pass);
    }

    @Override
    public void setRole() {
        user.setRole("manager");
    }

    @Override
    public void setId() {
        user.setId("M" + adminCount);
        adminCount++;
    }

    @Override
    public void setEmail(String email) {
        user.setEmail(email);
    }

    @Override
    public void setDateJoined(Date dateJoined) {
        user.setDateJoined(dateJoined);
    }

    @Override
    public void setCellNum(int cellNum) {
        user.setCellNum(cellNum);
    }

    @Override
    public User getUser() {
        return user;
    }
}

