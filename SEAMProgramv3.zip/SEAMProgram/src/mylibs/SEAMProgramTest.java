/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author djbgr
 */
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class SEAMProgramTest {
    public static void main(String[] args) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SEAMProgram program = SEAMProgram.getInstance();
        
        // Create sample data
        try {
            // Add sample rooms
            Room room1 = new Room("1", "Room A");
            Room room2 = new Room("2", "Room B");
            program.getRoomList().add(room1);
            program.getRoomList().add(room2);
            
            // Add sample equipment
            Equipment equip1 = new Equipment("1", "projector", "good");
            Equipment equip2 = new Equipment("2", "TV", "broken");
            Equipment equip3 = new Equipment("3", "chair", "lost");
            Equipment equip4 = new Equipment("4", "monitor", "good");
            Equipment equip5 = new Equipment("5", "CPU", "needs repair");
            Equipment equip6 = new Equipment("6", "projector", "good");
            Equipment equip7 = new Equipment("7", "TV", "good");
            Equipment equip8 = new Equipment("8", "monitor", "broken");
            Equipment equip9 = new Equipment("9", "chair", "good");
            Equipment equip10 = new Equipment("10", "CPU", "lost");
            
            program.getEquipList().add(equip1);
            program.getEquipList().add(equip2);
            program.getEquipList().add(equip3);
            program.getEquipList().add(equip4);
            program.getEquipList().add(equip5);
            program.getEquipList().add(equip6);
            program.getEquipList().add(equip7);
            program.getEquipList().add(equip8);
            program.getEquipList().add(equip9);
            program.getEquipList().add(equip10);
            
            // Add sample users
            UserManager manager = new UserManager(new DefaultUserBuilder());
            Date dateJoined = dateFormat.parse("2024-01-01");
            User user1 = manager.constructUser("1", "John Doe", "password", dateJoined, 1234567890);
            program.getUserList().add(user1);
            
            // Save to file
            program.saveToFile();
            
            // Clear data and load from file
            program.getEquipList().clear();
            program.getRoomList().clear();
            program.getUserList().clear();
            program.loadFromFile();
            
            // Display equipment conditions
            
            System.out.println("Equipment Condition:\n" + program.displayEquipCondition(true));
            
            // Display restock list
            
            System.out.println("\nRestock List:\n" + program.displayRestockList());
            
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}

