/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class Room {
    private String name;
    private String id;
    private final ArrayList<Equipment> equipmentList = new ArrayList<>();

    public Room(String id, String name) {
        this.id = id;
        this.name = name;
        
    }

    public void assignEquipment(Equipment equipment) {
        equipmentList.add(equipment);
        equipment.setRoom(this.name); // Set the room for the equipment
    }
    public void unassignEquipment(Equipment equipment) {
        equipmentList.remove(equipment);
        equipment.setRoom("None"); // Set the room for the equipment
    }
    // Getter and setter
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;      
    }   

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ArrayList<Equipment> getEquipmentList() {
        return equipmentList;
    }
    
    
}