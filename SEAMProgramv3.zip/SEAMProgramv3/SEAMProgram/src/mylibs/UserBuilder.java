/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

import java.util.Date;

/**
 *
 * @author Administrator
 */
public interface UserBuilder {
    public void setName(String name);
    public void setPass(String pass);
    public void setRole();
    public void setId();
    public void setEmail(String email);
    public void setDateJoined(Date dateJoined);
    public void setCellNum(int cellNum);
    public User getUser();
}
