/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author Administrator
 */
public class Equipment {
    private int[] idcounter = {1,1,1,1,1};
    private String id;
    private String name;
    private String condition;
    private String room; // Where it is currently assigned

    public Equipment(String name, String condition) {
        switch(name){
            case "projector" -> {
                this.id = "P"+  idcounter[0];
                idcounter[0]++;
            }
            case "TV" -> {
                this.id = "T"+  idcounter[0];
                idcounter[1]++;
            }
            case "Chair" -> {
                this.id = "C"+  idcounter[0];
                idcounter[2]++;
            }
            case "Monitor" -> {
                this.id = "M"+  idcounter[0];
                idcounter[3]++;
            }
            case "CPU" -> {
                this.id = "CPU"+  idcounter[0];
                idcounter[4]++;
            }
        }
        this.condition = condition;
        this.room = "none";
        //defined types of equipment
        if ("projector".equalsIgnoreCase(name)||"TV".equalsIgnoreCase(name)||"Chair".equalsIgnoreCase(name)||"Monitor".equalsIgnoreCase(name)||"CPU".equalsIgnoreCase(name))
            this.name = name;
    }

    // Getters and setters
    public String getId(){ 
        return id; 
    }
    public String getName(){ 
        return name; 
    }
    public String getCondition(){ 
        return condition; 
    }
    public String getRoom(){
        return room; 
    } 

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public void setRoom(String room) { 
        this.room = room;
    }
}
