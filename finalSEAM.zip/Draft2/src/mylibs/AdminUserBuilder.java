/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author Administrator
 */
import java.util.Date;

public class AdminUserBuilder implements UserBuilder {
    private User user;
  
    
    public AdminUserBuilder() {
        user = new Admin();
        user.setHasAccess();
        user.setRank();
    }

    @Override
    public void setName(String name) {
        user.setName(name);
    }

    @Override
    public void setPass(String pass) {
        user.setPass(pass);
    }

    @Override
    public void setRole() {
        user.setRole("Admin");
    }

    @Override
    public void setId() {
        user.setId("A" + String.format("%04d", System.currentTimeMillis() % 10000));
    }

    @Override
    public void setEmail(String email) {
        user.setEmail(email);
    }
    
    
    @Override
    public void setDateJoined(Date dateJoined) {
        user.setDateJoined(dateJoined);
    }
    
    @Override
    public void setAgeText(int AgeText) {
        user.setAgeText(AgeText);
    }

    @Override
    public User getUser() {
        return user;
    }
    
    
}

