/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mylibs;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author Administrator
 */
public class SEAMProgram {
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    static SEAMProgram instance = null;
    private ArrayList<Equipment> equipList;
    private ArrayList<Room> roomList;
    private ArrayList<User> userList;
    


    public ArrayList<Equipment> getEquipList() {
        return equipList;
    }

    public ArrayList<Room> getRoomList() {
        return roomList;
    }

    public ArrayList<User> getUserList() {
        return userList;
    }
    
    private SEAMProgram() {
        userList = new ArrayList<>();
        equipList = new ArrayList<>();
        roomList = new ArrayList<>();
        
        try {
            readFromText();
        } catch (IOException | ParseException e) {
            System.out.println("File not found or parse error. Starting with a new instance.");
        }
    }

    public static SEAMProgram getInstance() {
        if (instance == null) {
            instance = new SEAMProgram();
        }
        return instance;
    }
    
    //filestreamstuff
    
     public void writeToText() throws FileNotFoundException {
        try (PrintWriter equipmentWriter = new PrintWriter("equipment.txt");
             PrintWriter roomWriter = new PrintWriter("rooms.txt");
             PrintWriter userWriter = new PrintWriter("users.txt")) {
             
            for (Equipment equipment : equipList) {
                String equipmentData = equipment.getId() + "|" + equipment.getName() + "|" +
                        equipment.getCondition() + "|" + equipment.getRoom();
                equipmentWriter.println(equipmentData);
            }
            
            for (Room room : roomList) {
                String roomData = room.getId() + "|" + room.getName();
                roomWriter.println(roomData);
            }
            
            for (User user : userList) {
            String dateStr = dateFormat.format(user.getDateJoined()); // format to make a date to a string type
            String userData = user.getId() + "|" + user.getName() + "|" + user.getPass() + "|" + user.getRole() + "|"                          
                            + user.getEmail() + "|" + dateStr + "|" + user.getAgeText();
            
            userWriter.println(userData);
            }

        }
    }


//     Combined read method
    public void readFromText() throws IOException, ParseException {
        
        equipList = new ArrayList<>();
        roomList = new ArrayList<>();
        userList = new ArrayList<>();
        try (BufferedReader equipmentReader = new BufferedReader(new FileReader("equipment.txt"));
             BufferedReader roomReader = new BufferedReader(new FileReader("rooms.txt"));
             BufferedReader userReader = new BufferedReader(new FileReader("users.txt"));) {
             
            String line;
            while ((line = roomReader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 2) {
                    Room room = new Room(parts[1]);
                    room.setId(parts[0]);
                    roomList.add(room);
                }
            }
            while ((line = equipmentReader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 4) {
                    Equipment e = new Equipment(parts[1], parts[2]);
                    e.setId(parts[0]);
                    e.setRoom(parts[3]);
                    for (Room r: roomList)
                        if (r.getName().equalsIgnoreCase(parts[3]))
                            r.assignEquipment(e);
                    equipList.add(e);
                }
            }
            
            
            UserManager manager;
            while ((line = userReader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 7) {
                    User user;
                    
                    if (parts[3].equals("manager")) {
                        manager = new UserManager(new AdminUserBuilder());
                        user = manager.constructUser(parts[1], parts[2], parts[4], Integer.parseInt(parts[6]), dateFormat.parse(parts[5]));
                        user.setId(parts[0]);
                        user.setRole(parts[3]);
                    } else {
                        manager = new UserManager(new DefaultUserBuilder());
                        user = manager.constructUser(parts[1], parts[2], parts[4], Integer.parseInt(parts[6]), dateFormat.parse(parts[5]));
                        user.setId(parts[0]);
                        user.setRole(parts[3]);
                    }
                    userList.add(user);
                }
            }
          
        }
    }

    public void saveToFile() {
        try {
            writeToText();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void loadFromFile() throws ParseException {
        try {
            readFromText();
        } catch (Exception e) {
            System.out.println("File not found. Starting with a new instance.");
        }
    }

    
    
    
    
    public String assignEquip(String type, String roomname){
        Room setRoom = null;
        for (Room r:roomList)
            if (r.getName().equalsIgnoreCase(roomname))
                    setRoom = r;
        if (setRoom != null){
            for (Equipment e:equipList){
                if (e.getName().equalsIgnoreCase(type)
                                &&e.getRoom().equals("none")
                                &&!e.getCondition().equals("needs repair")
                                &&!e.getCondition().equals("broken")
                                &&!e.getCondition().equals("lost")){
                    setRoom.assignEquipment(e);
                    return "Assigned "+e.getId()+" "+e.getName()+" to "+setRoom.getName();
                }
            }
            return "No available Equipment";
        }
        else 
            return "Invalid Room";
    }
    
    public String displayRestockList(String key) {
        if (key.toLowerCase().equals("by type")) {
            StringBuilder list = new StringBuilder();
            list.append(String.format("%-10s %-10s\n", "Item", "Quantity"));
            list.append("-------------------------------\n");

            String[] types = {"projector", "TV", "Chair", "monitor", "CPU"};
            int[] count = new int[5]; //projector, TV, chair, monitor, CPU respectively

            for (Equipment e : this.equipList) {
                if (e.getCondition().equalsIgnoreCase("lost") || e.getCondition().equalsIgnoreCase("broken")) {
                    for (int i = 0; i < types.length; i++) {
                        if (e.getName().equalsIgnoreCase(types[i])) {
                            count[i]++;
                        }
                    }
                }
            }

            for (int i = 0; i < types.length; i++) {
                list.append(String.format("%-10s %-10d\n", types[i], Math.max(0, count[i])));
            }

            list.append("-------------------------------\n");
            return list.toString();
        } else {
            List<Equipment> sortedList = equipList.stream()
                .filter(e -> e.getCondition().equalsIgnoreCase("lost") || e.getCondition().equalsIgnoreCase("broken"))
                .sorted(Comparator.comparing(Equipment::getCondition))
                .collect(Collectors.toList());

            StringBuilder result = new StringBuilder();
            result.append(String.format("%-10s %-10s %-15s\n", "Name", "Room", "Condition"));
            result.append("-------------------------------------------------\n");
            for (Equipment equipment : sortedList) {
                result.append(String.format("%-10s %-10s %-15s\n",
                        equipment.getName(), equipment.getRoom(), equipment.getCondition()));
            }
            return result.toString();
        }
    }

    
    public String searchList(String id){
        StringBuilder list = new StringBuilder().append(String.format("%-10s %-20s %-15s %-10s\n", "ID", "Item", "Condition", "Room"));
        list.append("-----------------------------------------------------\n");
        if (findEquipment(id)==null){
            return "No items with that Id";
        }
        Equipment e = findEquipment(id);
        list.append(String.format("%-10s %-20s %-15s %-10s\n",e.getName(),e.getId(),e.getCondition(),e.getRoom()));
        return list.toString();
    }
    

    
    //management methods
    public Room findRoom(String id) {
        for (Room room : roomList) {
            if (room.getId().equals(id)) {
                return room;
            }
        }
        return null;
    }          
    public Equipment findEquipment(String id){
        for (Equipment e: equipList){
            if (e.getId().equalsIgnoreCase(id)){
                return e;
            }
        }   
        return null;
    }       
            
    
    public void editEquipment(String id,String room, String condition){
        if (findEquipment(id)==null){
            System.out.println("Not found");
            return;
        }
        findEquipment(id).setCondition(condition);  
        for (Room r:roomList)
            if (r.getName().equalsIgnoreCase(room))
                r.unassignEquipment(findEquipment(id));
        findEquipment(id).setRoom(room);
                        
    }
    public void addEquipment(String name, String condition) {
        Equipment equipment = new Equipment(name, condition);
        equipList.add(equipment);
    }
    
    public void removeEquipment(String id){
        if (findEquipment(id)==null){
            System.out.println("Not found");
            return;
        }
        equipList.remove(findEquipment(id));
    }
    
    public String addRoom(String name) {
        if (roomList.size() >= 3) {
            return "Maximum Room Capacity reached. Cannot add more rooms.\n";
        } else {
            Room room = new Room(name);
            roomList.add(room);
            return "Room" + name + " added successfully.\n";
        }
    }
    
    public void editRoom(String id, String name) {
        if (findRoom(id) != null) {
            findRoom(id).setName(name);
        }
    }
    
    public void removeRoom(String id) {
        if (findRoom(id) == null) {
            System.out.println("Not found");
            return;
        }
        roomList.remove(findRoom(id));
    }
    //end of management methods        
            
     
    
    

    public void returnEquipment(String id,String condition){
        if (findEquipment(id)==null){
            System.out.println("Not found");
            return;
        }
        for (Room r:roomList)
            if (r.getName().equalsIgnoreCase(findEquipment(id).getRoom()))
                r.unassignEquipment(findEquipment(id));
        findEquipment(id).setCondition(condition);
    }
    
    
    
    
    public String sortedConditionList(String key) {
        Comparator<Equipment> conditionComparator = Comparator.comparing(
            e -> switch (e.getCondition().toLowerCase()) {
                case "good" -> 1;
                case "needs repair" -> 2;
                case "broken" -> 3;
                case "lost" -> 4;
                default -> 5; 
            }
        );

        List<Equipment> sortedList = null;
        switch (key.toLowerCase()) {
            case "type" -> sortedList = equipList.stream()
                        .sorted(Comparator.comparing(Equipment::getName))
                        .collect(Collectors.toList());
            case "room" -> sortedList = equipList.stream()
                        .sorted(Comparator.comparing(Equipment::getRoom))
                        .collect(Collectors.toList());
            case "condition" -> sortedList = equipList.stream()
                        .sorted(conditionComparator)
                        .collect(Collectors.toList());
            default -> {
                return "Invalid key";
            }
        }

        StringBuilder result = new StringBuilder();
        result.append(String.format("%-10s %-15s %-15s %-10s\n", "ID","Name","Room","Condition"));
        result.append("-------------------------------------------------\n");
        for (Equipment equipment : sortedList) {
            result.append(String.format("%-10s %-15s %-15s %-10s\n",
                    equipment.getId(),equipment.getName(), equipment.getRoom(), equipment.getCondition()));
        }
        return result.toString();
    }
  

    public String displayAllUsers() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-10s %-20s %-30s %-10s %-15s %-5s\n", "ID", "Name", "Email", "Role", "Date Joined", "Age"));
        sb.append("--------------------------------------------------------------------------\n");
        for (User user : userList) {
            sb.append(String.format("%-10s %-20s %-30s %-10s %-15s %-5s\n",
                user.getId(),
                user.getName(),
                user.getEmail(),
                user.getRole(),
                dateFormat.format(user.getDateJoined()),
                user.getAgeText()));
        }
        return sb.toString();
    }

    public String displayAllEquipment() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-10s %-20s %-15s %-10s\n", "ID", "Item", "Condition", "Room"));
        sb.append("------------------------------------------------------------\n");
        for (Equipment equipment : equipList) {
            sb.append(String.format("%-10s %-20s %-15s %-10s\n",
                equipment.getId(),
                equipment.getName(),
                equipment.getCondition(),
                equipment.getRoom()));
        }
        return sb.toString();
    }


    public String displayAllRooms() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-20s %-20s\n", "ID", "Name"));
        sb.append("-------------------------------\n");
        for (Room room : roomList) {
            sb.append(String.format("%-20s %-20s\n",
                room.getId(),
                room.getName()));
        }
        return sb.toString();
    }


    
    
}
