package mylibs;

import java.text.SimpleDateFormat;

public class TestSEAMProgram {

    public static void main(String[] args) throws Exception {
        SEAMProgram program = SEAMProgram.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        // Adding Rooms
        program.addRoom("Room A");
        program.addRoom("Room B");
        program.addRoom("Room C");

        // Adding Equipment
        program.addEquipment("Projector", "good");
        program.addEquipment("Projector", "needs repair");
        program.addEquipment("TV", "good");
        program.addEquipment("TV", "needs repair");
        program.addEquipment("Monitor", "lost");
        program.addEquipment("CPU", "good");

        // Adding Users
        UserManager manager = new UserManager(new DefaultUserBuilder());
        program.getUserList().add(manager.constructUser("Alice", "password1", "alice@example.com", 25, dateFormat.parse("2023-01-01")));
        program.getUserList().add(manager.constructUser("Bob", "password2", "bob@example.com", 30, dateFormat.parse("2023-02-01")));
        UserManager managerAdmin = new UserManager(new AdminUserBuilder());
        program.getUserList().add(managerAdmin.constructUser("Charlie", "password3", "charlie@example.com", 35, dateFormat.parse("2023-03-01")));
        program.saveToFile();
        program.loadFromFile();
        // Display All Equipment
        System.out.println("All Equipment:");
        System.out.println(program.displayAllEquipment());

        // Display All Rooms
        System.out.println("All Rooms:");
        System.out.println(program.displayAllRooms());

        // Display All Users
        System.out.println("All Users:");
        System.out.println(program.displayAllUsers());

        // Assign Equipment to Rooms
        System.out.println(program.assignEquip("Projector", "Room A"));
        System.out.println(program.assignEquip("TV", "Room B"));
        System.out.println(program.assignEquip("Monitor", "Room C"));

        // Display Updated Equipment List
        System.out.println("Updated Equipment List:");
        System.out.println(program.displayAllEquipment());

        // Display Sorted Equipment List by Condition
        System.out.println("Sorted Equipment by Condition:");
        System.out.println(program.sortedConditionList("condition"));

        // Display Restock List Per Type
        System.out.println("Restock List Per Type:");
        System.out.println(program.displayRestockList("per type"));
    }
}
