/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;


/**
 *
 * @author Administrator
 */
import java.util.Date;

public class User {
    private String name;
    private String pass;
    private String role;
    private String id;
    private String email; 
    private int AgeText;
    private Date dateJoined;   
    


    //setters
    public void setId(String id) {
        this.id = id;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setDateJoined(Date dateJoined) {
        this.dateJoined = dateJoined;
    }
    
    public void setAgeText(int AgeText) {
        this.AgeText = AgeText;
    }

    //getters
    public String getName() {
        return name;
    }

    public String getPass() {
        return pass;
    }

    public String getRole() {
        return role;
    }

    public String getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public Date getDateJoined() {
        return dateJoined;
    }
    
    public int getAgeText() {
        return AgeText;
    }

    public void setHasAccess() {
    }

    void setRank() {
        
    }
}

