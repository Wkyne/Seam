/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author Administrator
 */
public class Equipment {
    private int[] idcounter = {1,1,1,1,1};
    private String id;
    private String name;
    private String condition;
    private String room; // Where it is currently assigned

    public Equipment(String name, String condition) {
        switch(name.toLowerCase()){
            case "projector" -> {
                this.id = "P"+  idcounter[0];
                idcounter[0]++;
            }
            case "tv" -> {
                this.id = "T"+  idcounter[1];
                idcounter[1]++;
            }
            case "chair" -> {
                this.id = "C"+  idcounter[2];
                idcounter[2]++;
            }
            case "monitor" -> {
                this.id = "M"+  idcounter[3];
                idcounter[3]++;
            }
            case "cpu" -> {
                this.id = "CPU"+  idcounter[4];
                idcounter[4]++;
            }
        }
        this.condition = condition;
        this.room = "none";
        //defined types of equipment
        if ("projector".equalsIgnoreCase(name)||"TV".equalsIgnoreCase(name)||"Chair".equalsIgnoreCase(name)||"Monitor".equalsIgnoreCase(name)||"CPU".equalsIgnoreCase(name))
            this.name = name;
    }

    // Getters and setters
    public String getId(){ 
        return id; 
    }
    public String getName(){ 
        return name; 
    }
    public String getCondition(){ 
        return condition; 
    }
    public String getRoom(){
        return room; 
    } 

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public void setRoom(String room) { 
        this.room = room;
    }
}
