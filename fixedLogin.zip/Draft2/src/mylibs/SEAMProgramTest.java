/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mylibs;

/**
 *
 * @author djbgr
 */
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class SEAMProgramTest {
    public static void main(String[] args) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SEAMProgram program = SEAMProgram.getInstance();
        
        // Create sample data
        try {
//             Add sample rooms
            Room room1 = new Room("1", "Room A");
            Room room2 = new Room("2", "Room B");
            program.getRoomList().add(room1);
            program.getRoomList().add(room2);
            
         
            // Add sample equipment
            Equipment equip1 = new Equipment( "projector", "good");
            Equipment equip2 = new Equipment( "TV", "broken");
            Equipment equip3 = new Equipment( "chair", "lost");
            Equipment equip4 = new Equipment( "monitor", "good");
            Equipment equip5 = new Equipment( "CPU", "needs repair");
            Equipment equip6 = new Equipment( "projector", "good");
            Equipment equip7 = new Equipment("TV", "good");
            Equipment equip8 = new Equipment( "monitor", "broken");
            Equipment equip9 = new Equipment( "chair", "good");
            Equipment equip10 = new Equipment( "CPU", "lost");
            
            program.getEquipList().add(equip1);
            program.getEquipList().add(equip2);
            program.getEquipList().add(equip3);
            program.getEquipList().add(equip4);
            program.getEquipList().add(equip5);
            program.getEquipList().add(equip6);
            program.getEquipList().add(equip7);
            program.getEquipList().add(equip8);
            program.getEquipList().add(equip9);
            program.getEquipList().add(equip10);
            
            
               
            room1.assignEquipment(equip3);
             room2.assignEquipment(equip5);
              room2.assignEquipment(equip4);
               room1.assignEquipment(equip2);
                room1.assignEquipment(equip1);
                 room2.assignEquipment(equip8);
                  room1.assignEquipment(equip10);
            // Add sample users
            UserManager manager = new UserManager(new DefaultUserBuilder());
            Date dateJoined = dateFormat.parse("2024-01-01");
            //User user1 = manager.constructUser("1", "John Doe", "password", dateJoined, 1234567890);
            User user1 = manager.constructUser("1", "John Doe", "password", 27, dateJoined);
            program.getUserList().add(user1);
            
            // Save to file
            program.saveToFile();
            
            // Clear data and load from file
            program.getEquipList().clear();
            program.getRoomList().clear();
            program.getUserList().clear();
            program.loadFromFile();
            program.addRoom("1", "Room A");
            program.addRoom("2", "Room B");
            
            // Add sample equipment
            program.addEquipment("projector", "good");
            program.addEquipment("TV", "broken");
            program.addEquipment("chair", "lost");
            program.addEquipment("monitor", "good");
            program.addEquipment("CPU", "needs repair");
            
            // Add sample users
      
            //program.getUserList().add(manager.constructUser("1", "John Doe", "password", dateJoined, 1234567890));
            program.getUserList().add(manager.constructUser("1", "John Doe", "password", 1234567890, dateJoined));
            
            // Save to file
            program.saveToFile();
            
            // Clear data and load from file
            program.getEquipList().clear();
            program.getRoomList().clear();
            program.getUserList().clear();
            program.loadFromFile();
            program.displayAllEquipment();
            program.displayAllRooms();
            program.displayAllUsers();
            // Test display methods
            System.out.println("Equipment Condition:\n" + program.displayEquipCondition(true));
            System.out.println("\nRestock List:\n" + program.displayRestockList());
//            program.displayAllEquipment();
//            program.displayAllRooms();
//            program.displayAllUsers();
            
            // Test search method
            program.searchList("P1");
            System.out.println("searchlist");
            // Test filtered list method
            program.filteredList("projector", true);
            System.out.println("filteredList");
            // Test edit equipment method
            program.editEquipment("P1", "Room B", "good");
            System.out.println("editEquipment");
            // Test remove equipment method
            program.removeEquipment("P2");
            System.out.println("removeEquipment");
            // Test add room method
            program.addRoom("3", "Room C");
            System.out.println("addRoom");
            // Test edit room method
            program.editRoom("1", "Room A Updated");
            System.out.println("editRoom");
            // Test remove room method
            program.removeRoom("2");
            System.out.println("removeRoom");
            // Test return equipment method
            program.returnEquipment("1", "good");
            // Display equipment conditions
            System.out.println("returnEquipment");
            System.out.println("Equipment Condition:\n" + program.displayEquipCondition(true));
            
            // Display restock list
            
            System.out.println("\nRestock List:\n" + program.displayRestockList());
            
//           System.out.println( program.sortedDisplayEquipmentList());
//            
            
//            
            System.out.println("end of code");
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}

